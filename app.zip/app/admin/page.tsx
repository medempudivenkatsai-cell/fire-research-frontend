"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

export default function AdminPage() {
  const [key, setKey] = useState("");
  const [saved, setSaved] = useState("");

  useEffect(() => {
    const k = localStorage.getItem("adminKey") || "";
    setSaved(k ? "✅ Admin key is set" : "❌ Admin key not set");
  }, []);

  function save() {
    localStorage.setItem("adminKey", key.trim());
    setKey("");
    setSaved("✅ Admin key is set");
  }

  function clear() {
    localStorage.removeItem("adminKey");
    setSaved("❌ Admin key not set");
  }

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100">
      <div className="mx-auto max-w-xl p-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-semibold">Admin Access</h1>
          <Link href="/" className="text-sm text-zinc-300 underline">
            Back
          </Link>
        </div>

        <div className="mt-3 text-sm text-zinc-400">
          Set the Admin Key to enable <b>Upload</b> and <b>Delete</b>.
        </div>

        <div className="mt-6 rounded-2xl border border-zinc-800 bg-zinc-900 p-4">
          <div className="text-sm">{saved}</div>

          <input
            value={key}
            onChange={(e) => setKey(e.target.value)}
            placeholder="Paste admin key here"
            className="mt-3 w-full rounded-xl bg-zinc-950 border border-zinc-800 px-4 py-3 outline-none focus:border-zinc-600"
          />

          <div className="mt-3 flex gap-3">
            <button
              onClick={save}
              className="rounded-xl bg-blue-600 px-4 py-2 font-medium hover:bg-blue-500"
            >
              Save Key
            </button>
            <button
              onClick={clear}
              className="rounded-xl bg-zinc-800 px-4 py-2 font-medium hover:bg-zinc-700"
            >
              Remove Key
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
