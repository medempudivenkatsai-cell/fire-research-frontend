"use client";

import Link from "next/link";
import { useState } from "react";

const API =
  process.env.NEXT_PUBLIC_API_BASE ||
  process.env.NEXT_PUBLIC_API ||
  process.env.NEXT_PUBLIC_API_BASE_URL ||
  "http://127.0.0.1:8010";

export default function UploadPage() {
  const [title, setTitle] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);

  const adminKey = typeof window !== "undefined" ? localStorage.getItem("adminKey") || "" : "";

  async function upload() {
    setMsg("");

    if (!adminKey) {
      setMsg("Admin key not set. Go to Admin page and save the key first.");
      return;
    }
    if (!file) {
      setMsg("Please choose a PDF file.");
      return;
    }

    setBusy(true);
    try {
      const form = new FormData();
      form.append("file", file);
      form.append("title", title.trim() || file.name);

      const r = await fetch(`${API}/upload`, {
        method: "POST",
        headers: { "x-admin-key": adminKey },
        body: form,
      });

      const data = await r.json().catch(() => ({}));

      if (!r.ok) {
        setMsg(data?.detail ? String(data.detail) : "Upload failed.");
        setBusy(false);
        return;
      }

      setMsg("✅ Uploaded successfully!");
      setTitle("");
      setFile(null);
    } catch (e: any) {
      setMsg(e?.message || "Upload failed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100">
      <div className="mx-auto max-w-4xl p-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-semibold">Upload PDF</h1>
          <Link href="/" className="text-sm text-zinc-300 underline">
            Back
          </Link>
        </div>

        {!adminKey ? (
          <div className="mt-4 rounded-xl border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-200">
            Admin key not set. Open <Link className="underline" href="/admin">/admin</Link> and save the key.
          </div>
        ) : null}

        <div className="mt-6 rounded-2xl border border-zinc-800 bg-zinc-900 p-4">
          <label className="block text-sm text-zinc-300">Title (optional)</label>
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g., NFPA report — Fire patterns study"
            className="mt-2 w-full rounded-xl bg-zinc-950 border border-zinc-800 px-4 py-3 outline-none focus:border-zinc-600"
          />

          <label className="mt-4 block text-sm text-zinc-300">PDF File</label>
          <input
            type="file"
            accept="application/pdf"
            onChange={(e) => setFile(e.target.files?.[0] || null)}
            className="mt-2 block w-full text-sm text-zinc-300"
          />

          <div className="mt-4 flex gap-3">
            <button
              onClick={upload}
              disabled={busy}
              className="rounded-xl bg-blue-600 px-4 py-2 font-medium hover:bg-blue-500 disabled:opacity-60"
            >
              {busy ? "Uploading…" : "Upload"}
            </button>
            <Link
              href="/admin"
              className="rounded-xl bg-zinc-800 px-4 py-2 font-medium hover:bg-zinc-700"
            >
              Admin Key
            </Link>
          </div>

          {msg ? <div className="mt-3 text-sm text-zinc-300">{msg}</div> : null}
        </div>
      </div>
    </div>
  );
}
