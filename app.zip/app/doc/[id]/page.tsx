"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useSearchParams, useParams, useRouter } from "next/navigation";
import PDFViewerClient from "@/components/PDFViewerClient";
import CommentsPanel from "@/components/CommentsPanel";

const API =
  process.env.NEXT_PUBLIC_API_BASE ||
  process.env.NEXT_PUBLIC_API ||
  process.env.NEXT_PUBLIC_API_BASE_URL ||
  "http://127.0.0.1:8010";

export default function DocPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const sp = useSearchParams();

  const docId = params.id;
  const page = Number(sp.get("page") || "1");

  const [doc, setDoc] = useState<any>(null);
  const [err, setErr] = useState("");

  const adminKey = typeof window !== "undefined" ? localStorage.getItem("adminKey") || "" : "";

  useEffect(() => {
    (async () => {
      setErr("");
      const r = await fetch(`${API}/documents/${docId}`, { cache: "no-store" });
      const data = await r.json();
      if (!r.ok) {
        setErr(data?.detail || "Failed to load document");
        return;
      }
      setDoc(data);
    })();
  }, [docId]);

  async function doDelete() {
    if (!adminKey) {
      alert("Admin key not set. Go to /admin and set it.");
      return;
    }
    if (!confirm("Delete this PDF permanently?")) return;

    const r = await fetch(`${API}/documents/${docId}`, {
      method: "DELETE",
      headers: { "x-admin-key": adminKey },
    });

    if (!r.ok) {
      const data = await r.json().catch(() => ({}));
      alert(data?.detail || "Delete failed");
      return;
    }

    router.push("/");
  }

  if (err) {
    return (
      <div className="min-h-screen bg-zinc-950 text-zinc-100 p-6">
        <Link href="/" className="underline text-zinc-300">Back</Link>
        <div className="mt-4 text-red-300">{err}</div>
      </div>
    );
  }

  if (!doc) {
    return <div className="min-h-screen bg-zinc-950 text-zinc-100 p-6">Loading…</div>;
  }

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100">
      <div className="mx-auto max-w-6xl p-4">
        <div className="flex items-center justify-between gap-3">
          <div className="truncate">
            <Link href="/" className="text-sm text-zinc-300 underline">Back</Link>
            <div className="mt-1 text-lg font-semibold truncate">{doc.title}</div>
          </div>

          <div className="flex gap-2">
            <a
              href={doc.pdf_url}
              target="_blank"
              className="rounded-xl bg-zinc-800 px-3 py-2 text-sm font-medium hover:bg-zinc-700"
            >
              Open PDF
            </a>

            {adminKey ? (
              <button
                onClick={doDelete}
                className="rounded-xl bg-red-600 px-3 py-2 text-sm font-medium hover:bg-red-500"
              >
                Delete
              </button>
            ) : null}
          </div>
        </div>

        <div className="mt-4 grid grid-cols-1 lg:grid-cols-[1fr_420px] gap-3">
          <div className="min-h-[70vh] rounded-2xl overflow-hidden border border-zinc-800 bg-zinc-900">
            <PDFViewerClient url={doc.pdf_url} initialPage={page} onPageChange={() => {}} />
          </div>

          <div className="rounded-2xl border border-zinc-800 bg-zinc-900 overflow-hidden">
            <div className="h-[70vh] overflow-auto">
              <CommentsPanel apiBase={API} documentId={doc.id} page={page} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
