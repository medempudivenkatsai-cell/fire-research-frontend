"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

const API =
  process.env.NEXT_PUBLIC_API_BASE ||
  process.env.NEXT_PUBLIC_API ||
  process.env.NEXT_PUBLIC_API_BASE_URL ||
  "http://127.0.0.1:8010";

type DocRow = {
  id: string;
  title: string;
  created_at: string;
};

type SearchHit = {
  doc_id: string;
  title: string;
  created_at: string;
  page?: number;
  page_number?: number;
  snippet?: string;
};

export default function Home() {
  const [docs, setDocs] = useState<any[]>([]);
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(false);

  async function loadAll() {
    setLoading(true);
    const r = await fetch(`${API}/documents`, { cache: "no-store" });
    const data = await r.json();

    // Deduplicate by id (prevents duplicate React keys)
    const arr = Array.isArray(data) ? data : [];
    const unique = Array.from(new Map(arr.map((d: any) => [d.id, d])).values());

    setDocs(unique);
    setLoading(false);
  }

  async function search() {
    if (!q.trim()) return loadAll();

    setLoading(true);
    const r = await fetch(`${API}/search?q=${encodeURIComponent(q.trim())}`, { cache: "no-store" });
    const data = await r.json();
    setDocs(Array.isArray(data) ? data : []);
    setLoading(false);
  }

  useEffect(() => {
    loadAll();
  }, []);

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100">
      <div className="mx-auto max-w-5xl p-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold">Fire Research Library</h1>
            <p className="text-zinc-400 mt-1">
              Upload PDFs, search text, and add investigator notes (comments).
            </p>
          </div>
          <Link
            href="/upload"
            className="rounded-xl bg-zinc-100 px-4 py-2 text-zinc-950 font-medium hover:bg-white"
          >
            Upload PDF
          </Link>
          </div>
          <Link
           href="/admin"
            className="rounded-xl bg-zinc-800 px-4 py-2 text-zinc-100 font-medium hover:bg-zinc-700"
          >
            Admin
          </Link>

        <div className="mt-6 flex gap-3">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search (e.g., fire patterns, ventilation, drywall...)"
            className="w-full rounded-xl bg-zinc-900 border border-zinc-800 px-4 py-3 outline-none focus:border-zinc-600"
          />
          <button
            onClick={search}
            className="rounded-xl bg-blue-600 px-4 py-3 font-medium hover:bg-blue-500"
          >
            Search
          </button>
          <button
            onClick={() => {
              setQ("");
              loadAll();
            }}
            className="rounded-xl bg-zinc-800 px-4 py-3 font-medium hover:bg-zinc-700"
          >
            Clear
          </button>
        </div>

        <div className="mt-6">
          {loading ? (
            <div className="text-zinc-400">Loading…</div>
          ) : docs.length === 0 ? (
            <div className="text-zinc-400">No documents yet. Upload one.</div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {docs.map((d: any, i: number) => {
                const isHit = !!d.doc_id && !d.id;
                const docId = isHit ? d.doc_id : d.id;
                const page = (d.page ?? d.page_number ?? 1) as number;

                return (
                  <Link
                    key={isHit ? `${docId}-${page}-${i}` : docId}
                    href={isHit ? `/doc/${docId}?page=${page}` : `/doc/${docId}`}
                    className="rounded-2xl border border-zinc-800 bg-zinc-900 p-4 hover:border-zinc-600"
                  >
                    <div className="text-lg font-medium">{d.title}</div>

                    {isHit ? (
                      <div className="mt-2 text-sm text-zinc-400">Match on page: {page}</div>
                    ) : (
                      <div className="mt-2 text-sm text-zinc-400">
                        Added: {new Date(d.created_at).toLocaleString()}
                      </div>
                    )}

                    {d.snippet ? (
                      <div className="mt-2 text-sm text-zinc-300 line-clamp-3">{d.snippet}</div>
                    ) : null}
                  </Link>
                );
              })}
            </div>
          )}
        </div>

        <div className="mt-10 text-xs text-zinc-500">Backend: {API}</div>
      </div>
    </div>
  );
}
