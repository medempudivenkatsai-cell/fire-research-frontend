"use client";

import { useEffect, useState } from "react";

type CommentRow = {
  id: number;
  created_at: string;
  document_id: string;
  page_number: number;
  author: string;
  body: string;
  selected_text?: string | null;
};

export default function CommentsPanel({
  apiBase,
  documentId,
  page,
}: {
  apiBase: string;
  documentId: string;
  page: number;
}) {
  const [author, setAuthor] = useState("Anonymous");
  const [body, setBody] = useState("");
  const [items, setItems] = useState<CommentRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  async function load() {
    if (!documentId) return;
    setLoading(true);
    setErr("");
    try {
      const r = await fetch(
        `${apiBase}/comments?document_id=${encodeURIComponent(documentId)}&page_number=${page}`,
        { cache: "no-store" }
      );
      if (!r.ok) throw new Error(await r.text());
      const data = await r.json();
      setItems(Array.isArray(data) ? data : []);
    } catch (e: any) {
      setErr(e?.message || "Failed to load comments");
      setItems([]);
    } finally {
      setLoading(false);
    }
  }

  async function add() {
    if (!documentId) return;
    if (!body.trim()) return;

    setErr("");
    try {
      const r = await fetch(`${apiBase}/comments`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          document_id: documentId,
          page_number: page,
          author: author.trim() || "Anonymous",
          body: body.trim(),
        }),
      });

      if (!r.ok) throw new Error(await r.text());

      setBody("");
      await load();
    } catch (e: any) {
      setErr(e?.message || "Failed to add comment");
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [documentId, page]);

  return (
    <div className="p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="font-semibold">Comments</div>
          <div className="text-xs text-zinc-400">
            Page {page} • Doc {documentId.slice(0, 8)}…
          </div>
        </div>
      </div>

      <div className="mt-3 flex gap-2">
        <input
          value={author}
          onChange={(e) => setAuthor(e.target.value)}
          placeholder="Your name"
          className="flex-1 rounded-xl bg-zinc-900 border border-zinc-800 px-3 py-2 text-sm outline-none focus:border-zinc-600"
        />
        <button
          onClick={add}
          className="rounded-xl bg-blue-600 px-4 py-2 text-sm font-medium hover:bg-blue-500"
        >
          Add
        </button>
      </div>

      <textarea
        value={body}
        onChange={(e) => setBody(e.target.value)}
        placeholder="Write a note..."
        rows={3}
        className="mt-2 w-full rounded-xl bg-zinc-900 border border-zinc-800 px-3 py-2 text-sm outline-none focus:border-zinc-600"
      />

      {err ? <div className="mt-2 text-sm text-red-300">{err}</div> : null}
      {loading ? <div className="mt-2 text-sm text-zinc-400">Loading…</div> : null}

      <div className="mt-4 space-y-3">
        {items.length === 0 ? (
          <div className="text-sm text-zinc-400">No comments yet on this page.</div>
        ) : (
          items.map((c) => (
            <div
              key={c.id}
              className="rounded-2xl border border-zinc-800 bg-zinc-950/40 p-3"
            >
              <div className="text-sm font-semibold">
                {c.author} <span className="text-zinc-400 font-normal">•</span>{" "}
                <span className="text-zinc-400 font-normal">
                  {new Date(c.created_at).toLocaleString()}
                </span>
              </div>
              <div className="mt-1 text-sm text-zinc-200 whitespace-pre-wrap">
                {c.body}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
