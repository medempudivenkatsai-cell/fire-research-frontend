"use client";

import Link from "next/link";
import { useState } from "react";

const API = process.env.NEXT_PUBLIC_API || process.env.NEXT_PUBLIC_API_BASE_URL || "http://127.0.0.1:8010";
const adminKey = typeof window !== "undefined" ? localStorage.getItem("adminKey") : "";

await fetch(`${API}/upload`, {
  method: "POST",
  headers: adminKey ? { "x-admin-key": adminKey } : undefined,
  body: formData,
});

export default function UploadPage() {
  const [title, setTitle] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [msg, setMsg] = useState<string>("");
  const [busy, setBusy] = useState(false);

  async function upload() {
    setMsg("");
    if (!file) return setMsg("Please choose a PDF file.");
    setBusy(true);

    const form = new FormData();
    form.append("file", file);
    form.append("title", title || file.name);

    const r = await fetch(`${API}/upload`, {
      method: "POST",
      body: form,
    });

    const data = await r.json().catch(() => ({}));
    setBusy(false);

    if (!r.ok) {
      setMsg(data?.detail || "Upload failed.");
      return;
    }

    setMsg("Uploaded successfully ✅ Go back and open the document.");
    setTitle("");
    setFile(null);
  }

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100">
      <div className="mx-auto max-w-3xl p-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-semibold">Upload PDF</h1>
          <Link href="/" className="text-zinc-300 hover:text-white">← Back</Link>
        </div>

        <div className="mt-6 rounded-2xl border border-zinc-800 bg-zinc-900 p-5">
          <label className="block text-sm text-zinc-300">Title (optional)</label>
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g., NFPA report – Fire patterns study"
            className="mt-2 w-full rounded-xl bg-zinc-950 border border-zinc-800 px-4 py-3 outline-none focus:border-zinc-600"
          />

          <label className="mt-5 block text-sm text-zinc-300">PDF File</label>
          <input
            type="file"
            accept="application/pdf"
            onChange={(e) => setFile(e.target.files?.[0] || null)}
            className="mt-2 block w-full text-sm text-zinc-300"
          />

          <button
            onClick={upload}
            disabled={busy}
            className="mt-6 w-full rounded-xl bg-blue-600 px-4 py-3 font-medium hover:bg-blue-500 disabled:opacity-60"
          >
            {busy ? "Uploading…" : "Upload"}
          </button>

          {msg && <div className="mt-4 text-sm text-zinc-200">{msg}</div>}
        </div>
      </div>
    </div>
  );
}
