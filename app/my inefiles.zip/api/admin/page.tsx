"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

export default function AdminPage() {
  const [key, setKey] = useState("");

  useEffect(() => {
    setKey(localStorage.getItem("adminKey") || "");
  }, []);

  const save = () => {
    localStorage.setItem("adminKey", key.trim());
    alert("Saved admin key in this browser");
  };

  const clear = () => {
    localStorage.removeItem("adminKey");
    setKey("");
    alert("Cleared admin key");
  };

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-xl mx-auto space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-white">Admin Access</h1>
          <Link className="text-sm underline text-zinc-200" href="/">
            Back
          </Link>
        </div>

        <div className="rounded-xl border border-white/10 bg-black/30 p-4">
          <label className="block text-sm text-zinc-200 mb-2">Admin Key</label>
          <input
            value={key}
            onChange={(e) => setKey(e.target.value)}
            className="w-full px-3 py-2 rounded bg-black/40 border border-white/10 text-white"
            placeholder="Enter admin key…"
          />
          <div className="flex gap-2 mt-3">
            <button
              onClick={save}
              className="px-4 py-2 rounded bg-white/90 text-black font-semibold"
            >
              Save
            </button>
            <button
              onClick={clear}
              className="px-4 py-2 rounded bg-white/10 text-white"
            >
              Clear
            </button>
          </div>
          <p className="text-xs text-zinc-300 mt-3">
            This is stored only in this browser (localStorage).
          </p>
        </div>
      </div>
    </div>
  );
}
