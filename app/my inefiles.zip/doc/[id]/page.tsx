"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useParams, useSearchParams } from "next/navigation";
import PDFViewerClient from "@/components/PDFViewerClient";
import CommentsPanel from "@/components/CommentsPanel";

const API =
  process.env.NEXT_PUBLIC_API ||
  process.env.NEXT_PUBLIC_API_BASE_URL ||
  "http://127.0.0.1:8010";

type Doc = {
  id: string;
  title: string;
  storage_path: string;
  created_at: string;
  pdf_url: string;
};

export default function DocPage() {
  const params = useParams<{ id: string }>();
  const searchParams = useSearchParams();

  const [doc, setDoc] = useState<Doc | null>(null);
  const [err, setErr] = useState<string>("");
  const [loading, setLoading] = useState(true);

  const initialPage = Math.max(1, Number(searchParams.get("page") || "1") || 1);
  const [page, setPage] = useState<number>(initialPage);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      setLoading(true);
      setErr("");
      try {
        const res = await fetch(`${API}/documents/${params.id}`, { cache: "no-store" });
        if (!res.ok) throw new Error(`Failed to load document (${res.status})`);
        const data = await res.json();
        if (!cancelled) setDoc(data);
      } catch (e: any) {
        if (!cancelled) setErr(e?.message || "Failed to load document");
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, [params.id]);

  if (loading) return <div style={{ padding: 16 }}>Loading…</div>;
  if (err) return <div style={{ padding: 16, color: "crimson" }}>{err}</div>;
  if (!doc) return <div style={{ padding: 16 }}>Not found.</div>;

  return (
    <div className="min-h-screen flex flex-col">
      {/* Top bar */}
      <div className="p-3 border-b border-white/10 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Link href="/" className="underline">
            ← Back
          </Link>
          <div className="text-sm opacity-80">
            <span className="font-semibold">{doc.title || "Document"}</span>
            <span className="opacity-60"> • </span>
            <span className="opacity-60">Doc: {doc.id}</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-sm opacity-80">Page</span>
          <input
            value={page}
            onChange={(e) => setPage(Math.max(1, Number(e.target.value) || 1))}
            className="w-20 px-2 py-1 rounded bg-white/10 border border-white/10"
          />
          <a
            className="underline text-sm"
            href={`/doc/${doc.id}?page=${page}`}
            title="Refresh link with page"
          >
            Link
          </a>
        </div>
      </div>

      {/* Main split */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-[1fr_420px] gap-0">
        {/* PDF */}
        <div className="min-h-[60vh] lg:min-h-0">
          <div className="h-[70vh] lg:h-[calc(100vh-56px)]">
            <PDFViewerClient url={doc.pdf_url} page={page} />
          </div>
        </div>

        {/* Comments */}
        <div className="border-l border-white/10">
          <div className="h-[calc(100vh-56px)] overflow-auto">
            <CommentsPanel apiBase={API} documentId={doc.id} page={page} />
          </div>
        </div>
      </div>
    </div>
  );
}
